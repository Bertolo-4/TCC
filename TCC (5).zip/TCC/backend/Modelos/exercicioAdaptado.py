class exercicioAdaptado:
    def __init__(self, enunnciado_adaptado,id_adaptado=None, id_exercicio=None, id_usuario=None):
        self.id_adaptado = id_adaptado
        self.id_exercicio = id_exercicio
        self.id_usuario =  id_usuario   
        self.enunciado_adaptado = enunnciado_adaptado