class perfilAluno:
    def __init__(self, dificuldades, facilidades, id_perfil=None, id_usuario=None):
        self.id_perfil = id_perfil
        self.dificuldades = dificuldades
        self.facilidades = facilidades
        self.id_usuario = id_usuario
       