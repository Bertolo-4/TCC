# routers/exercicios.py

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from typing import Optional

# Importa as classes e funções de outros arquivos
from Persistencia.exercicioDAO import ExercicioDAO
from apigemini import adaptar_exercicio, corrigir_codigo

# Cria a instância do roteador
router = APIRouter()
exercicio_dao = ExercicioDAO()

# =============================================================
# === MODELOS PYDANTIC PARA VALIDAR AS REQUISIÇÕES ===
# =============================================================
class ExercicioCreate(BaseModel):
    titulo: str
    enunciado: str
    linguagem: str = "Java"
    template_codigo: Optional[str] = None

class CodigoRequest(BaseModel):
    codigo: str

# =============================================================
# === ROTAS DA API ===
# =============================================================

# --- Rota para o Dashboard ---
@router.get("/exercicios", summary="Lista todos os exercícios disponíveis")
def get_todos_exercicios():
    return exercicio_dao.listar_todos()

# --- Rota para Criar um Novo Exercício (CORRIGIDA) ---
@router.post("/exercicios", summary="Cria um novo exercício")
def create_exercicio(exercicio_data: ExercicioCreate):
    novo_exercicio = exercicio_dao.inserir_exercicio(
        exercicio_data.titulo,
        exercicio_data.enunciado,
        exercicio_data.linguagem,
        exercicio_data.template_codigo
    )
    if not novo_exercicio:
        raise HTTPException(status_code=500, detail="Erro ao criar o exercício.")
    return novo_exercicio

# --- Rota para Buscar um Exercício Específico ---
@router.get("/exercicio/{exercicio_id}", summary="Obtém um exercício adaptado (com cache)")
def get_exercicio_com_cache(exercicio_id: int):
    exercicio = exercicio_dao.buscar_por_id(exercicio_id)
    if not exercicio:
        raise HTTPException(status_code=404, detail="Exercício não encontrado")

    if exercicio.get("enunciado_adaptado"):
        return exercicio
    
    try:
        texto_adaptado = adaptar_exercicio(exercicio["enunciado"], "", "")
        exercicio_dao.salvar_versao_adaptada(exercicio_id, texto_adaptado)
        exercicio["enunciado_adaptado"] = texto_adaptado
        return exercicio
    except Exception as e:
        raise HTTPException(status_code=500, detail="Falha ao adaptar o exercício.")

# --- Rota para Corrigir Código ---
@router.post("/corrigir-codigo/{exercicio_id}", summary="Corrige um trecho de código enviado")
def api_corrigir_codigo(request: CodigoRequest):
    try:
        feedback_ia = corrigir_codigo(request.codigo)
        return {"correcao": feedback_ia}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao processar código: {str(e)}")