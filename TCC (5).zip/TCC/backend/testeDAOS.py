from Modelos.usuario import usuario
from Modelos.perfilAluno import perfilAluno
from Modelos.exercicio import exercicio
from Modelos.exercicioAdaptado import exercicioAdaptado
from Modelos.codigo_resposta import codigo_resposta

from Persistencia.usuarioDAO import inserir_usuario, buscar_usuario
from Persistencia.perfilAlunoDAO import inserir_perfil_aluno, buscar_perfil_por_usuario
from Persistencia.exercicioDAO import inserir_exercicio, buscar_exercicio_por_id
from Persistencia.codigoRespostaDAO import inserir_codigo_resposta, buscar_respostas_por_usuario

# ----------------------------------------------------------------------

def main():
    print("=== Teste de DAOs do projeto SimpleCode ===")

    # 1️⃣ Criar ou buscar usuário
    print("\n🔹 Inserindo usuário...")
    novo_usuario = usuario(nome="Leonardo Teste", email="leoteste@example.com", senha="1234")
    usuario_existente = buscar_usuario(novo_usuario.email)
    if usuario_existente:
        print("Usuário já existe no banco.")
        novo_usuario = usuario_existente
    else:
        novo_usuario = inserir_usuario(novo_usuario)
        print(f"Usuário inserido com ID: {novo_usuario.id_usuario}")

    # 2️⃣ Criar perfil do aluno
    print("\n🔹 Inserindo perfil do aluno...")
    perfil = perfilAluno(dificuldades="Lógica e sintaxe", facilidades="Raciocínio lógico", id_usuario=novo_usuario.id_usuario)
    perfil_inserido = inserir_perfil_aluno(perfil)
    print(f"Perfil inserido com ID: {perfil_inserido.id_perfil}")

    # 3️⃣ Criar exercício
    print("\n🔹 Inserindo exercício...")
    ex = exercicio(titulo="Soma de números", enuciado="Crie um programa que some dois números inteiros.", linguagem="Python")
    ex_inserido = inserir_exercicio(ex)
    print(f"Exercício inserido com ID: {ex_inserido.id_exercicio}")

    # 4️⃣ Criar exercício adaptado
    print("\n🔹 Inserindo exercício adaptado...")
    adaptado = exercicioAdaptado(
        enunnciado_adaptado="Faça um programa simples que pede dois números e mostra o resultado da soma.",
        id_exercicio=ex_inserido.id_exercicio,
        id_usuario=novo_usuario.id_usuario
    )
   
    # 5️⃣ Criar código resposta
    print("\n🔹 Inserindo código resposta...")
    resposta = codigo_resposta(
        codigo_submetido="a = int(input()); b = int(input()); print(a + b)",
        codigo_corrigido="print(int(input()) + int(input()))",
        id_usuario=novo_usuario.id_usuario,
        id_exercicio=ex_inserido.id_exercicio
    )
    resposta_inserida = inserir_codigo_resposta(resposta)
    print(f"Resposta inserida com ID: {resposta_inserida.id_resposta}")

    # 6️⃣ Buscar dados
    print("\n🔹 Buscando perfil do aluno...")
    perfil_busca = buscar_perfil_por_usuario(novo_usuario.id_usuario)
    print("Perfil encontrado:", vars(perfil_busca) if perfil_busca else "Nenhum perfil encontrado.")

    print("\n🔹 Buscando exercício por ID...")
    ex_busca = buscar_exercicio_por_id(ex_inserido.id_exercicio)
    print("Exercício encontrado:", vars(ex_busca) if ex_busca else "Nenhum exercício encontrado.")

  
    print("\n🔹 Buscando respostas do usuário...")
    respostas_busca = buscar_respostas_por_usuario(novo_usuario.id_usuario)
    for r in respostas_busca:
        print(vars(r))

    print("\n✅ Teste concluído com sucesso!")

# ----------------------------------------------------------------------

if __name__ == "__main__":
    main()
