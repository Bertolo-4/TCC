# Persistencia/exercicioDAO.py

from ConexaoBanco.conexao import get_connection # Verifique se este caminho está correto
import mysql.connector
from typing import Optional

class ExercicioDAO:
    def buscar_por_id(self, exercicio_id: int):
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor(dictionary=True)
            sql = """
                SELECT 
                    id_exercicio, titulo, enunciado, 
                    enunciado_adaptado, linguagem, template_codigo
                FROM exercicio 
                WHERE id_exercicio = %s
            """
            cursor.execute(sql, (exercicio_id,))
            return cursor.fetchone()
        except mysql.connector.Error as error:
            print(f"Erro ao buscar exercício: {error}")
            return None
        finally:
            if conn and conn.is_connected():
                conn.close()

    def salvar_versao_adaptada(self, exercicio_id: int, texto_adaptado: str):
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            sql = "UPDATE exercicio SET enunciado_adaptado = %s WHERE id_exercicio = %s"
            cursor.execute(sql, (texto_adaptado, exercicio_id))
            conn.commit()
            return True
        except mysql.connector.Error as error:
            if conn: conn.rollback()
            print(f"Erro ao salvar versão adaptada: {error}")
            return False
        finally:
            if conn and conn.is_connected():
                conn.close()

    def listar_todos(self):
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor(dictionary=True)
            sql = "SELECT id_exercicio, titulo FROM exercicio"
            cursor.execute(sql)
            return cursor.fetchall()
        except mysql.connector.Error as error:
            print(f"Erro ao listar exercícios: {error}")
            return []
        finally:
            if conn and conn.is_connected():
                conn.close()

    # --- FUNÇÃO ATUALIZADA AQUI ---
    def inserir_exercicio(self, titulo: str, enunciado: str, linguagem: str, template_codigo: Optional[str]):
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            sql = "INSERT INTO exercicio (titulo, enunciado, linguagem, template_codigo) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (titulo, enunciado, linguagem, template_codigo))
            conn.commit()
            id_inserido = cursor.lastrowid
            return {"id_exercicio": id_inserido, "titulo": titulo}
        except mysql.connector.Error as error:
            if conn: conn.rollback()
            print(f"Erro ao inserir exercício: {error}")
            return None
        finally:
            if conn: conn.close()