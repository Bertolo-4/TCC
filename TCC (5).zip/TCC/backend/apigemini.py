from fastapi import FastAPI
from pydantic import BaseModel
import os
import google.generativeai as genai

# =======================
# CONFIGURAÇÃO DO CLIENTE
# =======================
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))


MODEL_NAME = "gemini-2.5-flash"

app = FastAPI(
    title="API de Assistência ao Aluno (Gemini 2.5)",
    version="1.0"
)


class AdaptarRequest(BaseModel):
    texto: str
  

class CorrigirRequest(BaseModel):
    codigo: str
  

# ==========================
# FUNÇÃO: ADAPTAR EXERCÍCIO
# ==========================
def adaptar_exercicio(texto: str, dificuldades: str, facilidades: str):
    prompt = f"""
Você é um revisor especializado em Linguagem Simples, seguindo o Guia de Linguagem Simples do Incaper.

Reescreva o exercício abaixo aplicando as seguintes regras:
- Use palavras comuns e conhecidas.
- Evite jargões e termos técnicos (explique se precisar usar).
- Prefira verbos a substantivos.
- Frases curtas (até 25 palavras).
- Ordem direta: sujeito + verbo + complemento.
- Prefira voz ativa.
- Parágrafos curtos (uma ideia por parágrafo).
- Organize o texto de forma lógica.
- Se possível, use listas para informações em sequência.
- Mantenha o sentido original.


Exercício original:
\"\"\"{texto}\"\"\"

Retorne apenas o exercício adaptado.
"""

    model = genai.GenerativeModel(MODEL_NAME)
    resposta = model.generate_content(prompt)

    return resposta.text.strip()


# ==========================
# FUNÇÃO: CORRIGIR CÓDIGO
# ==========================
def corrigir_codigo(codigo_aluno: str, enunciado_exercicio: str) -> str:
    """
    Recebe o código do aluno e o enunciado original para dar contexto à IA.
    """
    prompt = f"""
        Você é um professor de programação amigável e encorajador.
        Um aluno enviou o seguinte código como resposta para o exercício abaixo.

        Exercício Original:
        ---
        {enunciado_exercicio}
        ---

        Código do Aluno:
        ---
        {codigo_aluno}
        ---

        Por favor, faça uma análise completa e didática:
        1. Primeiramente, diga se o código do aluno resolve o problema proposto no exercício.
        2. Se o código tiver erros de sintaxe ou lógica, aponte-os de forma clara.
        3. Apresente o código corrigido e funcional dentro de um bloco de código.
        4. Explique em linguagem simples e passo a passo o que foi alterado e por quê.
        5. Se o código original já estiver correto, elogie o aluno, explique por que o código é uma boa solução e, se possível, mostre uma forma alternativa ou mais eficiente de resolver o problema.
    """
    model = genai.GenerativeModel("gemini-2.5-flash") 
    resposta = model.generate_content(prompt)
    return resposta.text.strip()

# ======================
# ROTAS DA API
# ======================
@app.post("/adaptar-exercicio/")
def api_adaptar_exercicio(request: AdaptarRequest):
    resultado = adaptar_exercicio(request.texto, request.dificuldades, request.facilidades)
    return {"exercicio_adaptado": resultado}


@app.post("/corrigir-codigo/")
def api_corrigir_codigo(request: CorrigirRequest):
    resultado = corrigir_codigo(request.codigo, request.dificuldades, request.facilidades)
    return {"correcao": resultado}


@app.get("/")
def home():
    return "API (Gemini 2.5) está no ar. Vá para /docs para testar."
