CREATE DATABASE simplecode;
USE  simplecode;


CREATE TABLE usuario (
id_usuario bigint not null auto_increment primary key, 
nome varchar(255) not null, 
email varchar(255) not null unique, 
senha varchar(255) not null
);

select * FROM usuario;

CREATE TABLE perfil_aluno (
id_perfil bigint not null auto_increment primary key, 
id_usuario bigint not null, 
dificuldades text,
facilidades text,
foreign key (id_usuario) references usuario (id_usuario)
);


CREATE TABLE exercicio (
id_exercicio bigint not null auto_increment primary key,
titulo varchar(255) not null,
enunciado text not null
);

ALTER TABLE exercicio ADD COLUMN linguagem VARCHAR(50) DEFAULT 'Java';
ALTER TABLE exercicio ADD COLUMN enunciado_adaptado text NULL DEFAULT NULL;
ALTER TABLE exercicio ADD COLUMN template_codigo TEXT NULL DEFAULT NULL;
DESCRIBE exercicio;
ALTER TABLE exercicio MODIFY COLUMN enunciado TEXT NOT NULL;
CREATE TABLE codigo_resposta (
id_resposta bigint not null auto_increment primary key,
id_usuario bigint not null,
id_exercicio bigint not null, 
codigo_submetido text not null,
codigo_corrigido text,
feedback text,
foreign key (id_usuario) references usuario (id_usuario),
foreign key (id_exercicio) references exercicio (id_exercicio)
);
ALTER TABLE exercicio ADD CONSTRAINT titulo_unico UNIQUE (titulo);

DELETE FROM codigo_resposta;

INSERT INTO exercicio (titulo, enunciado) 
VALUES ('Exercício 1', 'Este é o enunciado do primeiro exercício. O objetivo é fazer a página carregar dinamicamente.');

INSERT INTO exercicio (titulo, enunciado) 
VALUES ('Exercício 2', 'Este é o enunciado do primeiro exercício. O objetivo é fazer a página carregar dinamicamente.');


SELECT * from exercicio; 
SELECT * FROM exercicio WHERE titulo = 'Exercicio 2';

DELETE FROM exercicio WHERE id_exercicio = 5;

-- limpei os testes que adicionei fazendo os DAOS
DELETE FROM exercicio_adaptado where id_exercicio =  1;
DELETE FROM codigo_resposta WHERE id_exercicio = 1;
DELETE FROM exercicio where id_exercicio =  1;

DELETE FROM exercicio_adaptado where id_exercicio =  2;
DELETE FROM codigo_resposta WHERE id_exercicio = 2;
DELETE FROM exercicio where id_exercicio =  2;

DELETE FROM exercicio_adaptado where id_exercicio =  3;
DELETE FROM codigo_resposta WHERE id_exercicio = 3;
DELETE FROM exercicio where id_exercicio =  3;

UPDATE exercicio SET titulo = 'Exercicio 1' WHERE id_exercicio = 4; 


-- Passo 1: Desativa o modo de atualização segura temporariamente
SET SQL_SAFE_UPDATES = 0;

-- Passo 2: Agora, seus comandos de limpeza funcionarão
DELETE FROM codigo_resposta;
DELETE FROM exercicio;

-- Passo 3: Reinicia os contadores de ID
ALTER TABLE exercicio AUTO_INCREMENT = 1;
ALTER TABLE codigo_resposta AUTO_INCREMENT = 1;

-- Passo 4 (Opcional, mas recomendado): Reativa o modo de atualização segura
SET SQL_SAFE_UPDATES = 1;


INSERT INTO exercicio (titulo, enunciado, linguagem, template_codigo) VALUES
('Exercício 1: Avanço da Tecnologia', 'Muitas coisas mais antigas estão sendo ultrapassadas devido ao avanço da tecnologia e as locadoras não estão livres disso. Atualmente, a Star Video locadora está vendo como anda seus gastos para saberem se ainda é viável continuar com o estabelecimento. Seu trabalho é, dado um número de DVDs que a locadora possui e o valor que ela cobra por aluguel, mostrar o faturamento anual da locadora, sabendo que um terço dos DVDs são alugados por mês.\nConsidere que, quando um cliente atrasa a entrega, é cobrada uma multa de 10% sobre o valor do aluguel, e que um décimo dos DVDs alugados no mês são devolvidos com atraso. Sabe-se ainda que 2% dos DVDs acabam estragando ao longo do ano e que um décimo do total é comprado para reposição.\nVocê deve ler um número inteiro X, que representa o número de DVDs da locadora, e um valor flutuante Y, que representa o valor do aluguel de cada DVD. O programa deve calcular e mostrar o faturamento anual da locadora (incluindo as multas) e a quantidade total de DVDs que ela terá no final do ano, arredondando o total de DVDs e mostrando os valores com duas casas decimais.', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}'),

('Exercício 2: Gorjeta de Gunther', 'Monica Geller é uma ótima chef e uma mulher muito decidida. Quando abriu seu próprio restaurante, fez questão de escolher a dedo cada um de seus funcionários. Com isso, mesmo que não seja obrigatório, a maioria dos clientes acaba pagando 10% de gorjeta para o garçom, por sempre realizar um ótimo atendimento. Isso deixa Monica e seus funcionários muito felizes.\nGunther foi ao restaurante pela primeira vez e adorou tanto a comida quanto o atendimento, mas não sabia ao certo se conseguiria pagar o valor adicional da gorjeta.\nFaça um programa que auxilie Gunther a calcular o valor total da conta, incluindo a gorjeta de 10%. O programa deve ler um valor flutuante V, que corresponde aos gastos de Gunther no restaurante, e mostrar o valor total a ser pago, com no máximo duas casas após o ponto.', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}'),

('Exercício 3: Batmóvel', 'Coringa está atacando Gotham City novamente e Batman acaba de sair com seu batmóvel para ir atrás dele. Porém, percebe que precisa passar no posto de gasolina primeiro e, por ser o Batman, o dono do posto acaba fazendo um desconto na gasolina e no álcool conforme a tabela a seguir:\nÁlcool: até 20 litros (inclusive), desconto de 3% por litro; acima de 20 litros, desconto de 5% por litro.\n\nGasolina: até 20 litros (inclusive), desconto de 4% por litro; acima de 20 litros, desconto de 6% por litro.\n\nSabendo que o preço do litro da gasolina é R$ 2,50 e o do álcool é R$ 1,90, faça um programa que leia o número de litros X e o tipo de combustível Y (\"A\" para álcool e \"G\" para gasolina), e mostre o valor total a ser pago por Batman, com duas casas decimais.', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}'),

('Exercício 4: Assistente Virtual', 'Chegamos à década de 2030 e depois das lojas de varejo, bancos, laticínios e demais empresas, até posto de gasolina tem Assistente Virtual. Um posto pediu para que você programe um algoritmo que, dados uma distância e o tipo de carro do consumidor, calcule e mostre a estimativa de combustível necessária para a viagem.\nOs tipos de carro são:\nsedan, com autonomia de 12 km por litro;\n\nhatch, com autonomia de 9 km por litro;\n\ncompact, com autonomia de 8 km por litro.\n\nO programa deve ler um valor flutuante D, referente à distância da viagem em quilômetros (0 ≤ D ≤ 1000), e uma cadeia de caracteres T, indicando o tipo do carro (sedan, hatch ou compact).\nMostre a estimativa de combustível necessária, com uma casa decimal e o símbolo “L” indicando litros.', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}'),

('Exercício 5: Web namoro', 'Darren está desesperado para encontrar seu amor, por isso está usando todas as ferramentas que pode, como a internet. Porém, ele tem alguns pré-requisitos, sendo um deles a idade: ele gostaria que seu parceiro fosse mais velho que ele.\nFaça um programa que ajude Darren a filtrar suas opções de parceiro, lendo dois números inteiros X e Y, que representam respectivamente a idade de Darren e a de seu possível par.\nMostre se o parceiro tem a mesma idade (\"SAME\"), é mais velho (\"OLDER\") ou mais novo (\"NEWER\").', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}'),

('Exercício 6: Bicicletas de Andrew', 'Andrew Campbell é um bilionário, herdeiro dos negócios de seu pai, que gosta de pedalar nas horas vagas. Decidiu abrir sua própria loja de bicicletas no centro da cidade onde mora, para gerar mais empregos e poder finalmente trabalhar com algo que gosta.\nAndrew cobra 50% de acréscimo sobre o preço de custo de cada bicicleta e paga a cada vendedor dois salários mínimos, mais uma comissão de 15% sobre o preço de cada bicicleta vendida, dividida igualmente entre eles.\nFaça um programa que leia a quantidade de empregados E e a quantidade de bicicletas vendidas V, além do valor do salário mínimo S e do preço de custo de cada bicicleta B.\nO programa deve calcular e mostrar o salário final de cada empregado e o lucro da loja no primeiro mês, ambos com duas casas decimais.', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}'),

('Exercício 7: Hotel Olímpico', 'É época de olimpíadas e para isso todos resolveram construir um hotel para os visitantes que irão ver os jogos. Por causa da alta concorrência com outros hotéis, o gerente pediu para oferecer um desconto de 25% para aquele final de semana.\nSeu papel é, dado o número de apartamentos do hotel e o valor da diária do apartamento, informar: o valor promocional da diária; valor total a ser arrecadado caso a ocupação total (100%) seja atingida; valor a ser arrecadado caso a ocupação seja de somente 70%; valor que o hotel deixará de arrecadar por causa da promoção caso a ocupação seja de 100%.\nConsidere como entrada um número inteiro x, que será o número de apartamentos do hotel, e um valor flutuante de dupla precisão y, que representa o valor da diária de cada apartamento por fim de semana (0 < x ≤ 100 e 0 < y ≤ 300).', 'Java', 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        // Escreva sua lógica aqui\n    }\n}');